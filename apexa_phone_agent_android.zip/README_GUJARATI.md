# અપેક્ષા AI v2.1 — Native Android Phone Agent + WhatsApp Auto-Reply

આ વર્ઝનમાં ફુલ ફોન કંટ્રોલ (`AccessibilityService`) સાથે **WhatsApp અને WhatsApp Business ઑટો-રિપ્લાય (`NotificationListenerService`)** ઉમેરેલ છે — ફોન લોક હોય તો પણ અપેક્ષા AI ગ્રાહકોને જાતે જવાબ આપશે!

## મોબાઇલથી GitHub પર APK બનાવવાની રીત (ફોલ્ડર વગર)
1. GitHub રેપોઝિટરીમાં સીધી `apexa_phone_agent_android.zip` અપલોડ કરો.
2. **Add file → Create new file** માં `.github/workflows/build_apk.yml` બનાવી ZIP અનઝિપ કરીને `gradle assembleDebug` રન કરો.
3. **Actions → Artifacts → `ApexaAI-Phone-Agent-APK`** ડાઉનલોડ કરી ફોનમાં ઇન્સ્ટોલ કરો.
4. એપમાં **Accessibility ચાલુ કરો** અને **ઑટો-રિપ્લાય પરમિશન** (Notification Access) બંને ON કરો, પછી **WhatsApp ઑટો-રિપ્લાય** સ્વીચ ચાલુ કરો.
