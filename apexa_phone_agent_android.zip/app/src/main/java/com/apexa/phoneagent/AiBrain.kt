package com.apexa.phoneagent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiPlan(val reply: String, val actions: JSONArray)

object AiBrain {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

    private fun buildSystemPrompt(lang: String, screenText: String): String {
        val langName = when (lang) {
            "hi" -> "Hindi"
            "en" -> "English"
            else -> "Gujarati"
        }
        return """
You are અપેક્ષા AI (Apexa), an autonomous Android Phone Operating Agent.
Reply concisely in $langName (matching the user's language if they switch between Gujarati, Hindi, and English).
Current visible phone screen text: $screenText

You MUST return ONLY a valid JSON object (no markdown fences) with this exact schema:
{
  "reply": "Short natural spoken reply to the user",
  "actions": [
    {"type": "open_app", "value": "WhatsApp"},
    {"type": "call", "value": "9876543210"},
    {"type": "whatsapp", "phone": "919876543210", "message": "Hello"},
    {"type": "flashlight", "value": "on"},
    {"type": "volume", "value": "up"},
    {"type": "alarm", "hour": 7, "minute": 30, "value": "Wake up"},
    {"type": "search", "value": "Ahmedabad weather"},
    {"type": "settings", "value": "wifi"},
    {"type": "click_text", "value": "Send"},
    {"type": "type_text", "value": "Hello"},
    {"type": "scroll", "value": "down"},
    {"type": "nav", "value": "home"}
  ]
}
Include ONLY the actions needed for the user's request (or an empty array [] if it's just a question).
        """.trimIndent()
    }

    suspend fun ask(provider: String, apiKey: String, userText: String, lang: String, screenText: String): AiPlan =
        withContext(Dispatchers.IO) {
            val raw = callProvider(provider, apiKey, buildSystemPrompt(lang, screenText), userText)
            parsePlan(raw)
        }

    /** Generate a polite, short WhatsApp / WhatsApp Business auto-reply */
    suspend fun askAutoReply(
        provider: String,
        apiKey: String,
        sender: String,
        incomingMessage: String,
        lang: String,
        customRule: String
    ): String = withContext(Dispatchers.IO) {
        val langName = when (lang) { "hi" -> "Hindi"; "en" -> "English"; else -> "Gujarati" }
        val sys = "You are અપેક્ષા AI replying automatically on WhatsApp on behalf of the owner. " +
            "Write ONE short, polite reply (max 2 sentences) in $langName (or match the sender's language). " +
            "Owner's business instruction: $customRule. Do not add quotes or explanations."
        val user = "Sender: $sender\nMessage: $incomingMessage"
        callProvider(provider, apiKey, sys, user).trim()
    }

    private fun callProvider(provider: String, apiKey: String, sysPrompt: String, userText: String): String {
        val cleanKey = apiKey.replace(Regex("[\\s\"']"), "").trim()
        return when (provider.lowercase()) {
            "groq" -> callOpenAICompat(
                "https://api.groq.com/openai/v1/chat/completions",
                cleanKey,
                "llama-3.3-70b-versatile",
                sysPrompt,
                userText
            )
            "openrouter" -> callOpenAICompat(
                "https://openrouter.ai/api/v1/chat/completions",
                cleanKey,
                "openrouter/free",
                sysPrompt,
                userText
            )
            else -> callGemini(cleanKey, sysPrompt, userText)
        }
    }

    private fun callGemini(key: String, sysPrompt: String, userText: String): String {
        val models = listOf("gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash")
        var lastError = "Gemini API failed"
        for (model in models) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
            val bodyJson = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", "$sysPrompt\n\n$userText")))
                }))
            }
            val req = Request.Builder().url(url).post(bodyJson.toString().toRequestBody(JSON_MEDIA)).build()
            client.newCall(req).execute().use { resp ->
                val str = resp.body?.string().orEmpty()
                if (resp.isSuccessful) {
                    val text = JSONObject(str)
                        .optJSONArray("candidates")?.optJSONObject(0)
                        ?.optJSONObject("content")?.optJSONArray("parts")
                        ?.optJSONObject(0)?.optString("text")
                    if (!text.isNullOrBlank()) return text
                } else {
                    lastError = JSONObject(str).optJSONObject("error")?.optString("message") ?: "HTTP ${resp.code}"
                    if (resp.code in listOf(400, 401, 403)) throw RuntimeException(lastError)
                }
            }
        }
        throw RuntimeException(lastError)
    }

    private fun callOpenAICompat(endpoint: String, key: String, model: String, sysPrompt: String, userText: String): String {
        val bodyJson = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", sysPrompt))
                put(JSONObject().put("role", "user").put("content", userText))
            })
        }
        val req = Request.Builder()
            .url(endpoint)
            .addHeader("Authorization", "Bearer $key")
            .addHeader("X-Title", "Apexa Phone Agent")
            .post(bodyJson.toString().toRequestBody(JSON_MEDIA))
            .build()
        client.newCall(req).execute().use { resp ->
            val str = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(str).optJSONObject("error")?.optString("message") }.getOrNull()
                throw RuntimeException(msg ?: "HTTP ${resp.code}")
            }
            return JSONObject(str)
                .optJSONArray("choices")?.optJSONObject(0)
                ?.optJSONObject("message")?.optString("content")
                ?: throw RuntimeException("Empty AI reply")
        }
    }

    private fun parsePlan(raw: String): AiPlan {
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val start = cleaned.indexOf('{')
            val end = cleaned.lastIndexOf('}')
            val jsonStr = if (start >= 0 && end > start) cleaned.substring(start, end + 1) else cleaned
            val obj = JSONObject(jsonStr)
            AiPlan(
                reply = obj.optString("reply", "કામ પૂર્ણ થયું!"),
                actions = obj.optJSONArray("actions") ?: JSONArray()
            )
        } catch (_: Exception) {
            AiPlan(reply = raw.trim(), actions = JSONArray())
        }
    }
}
