package com.apexa.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ApexaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ApexaAccessibilityService? = null
            private set

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    fun readScreenText(maxItems: Int = 40): String {
        val root = rootInActiveWindow ?: return "Screen unavailable"
        val items = mutableListOf<String>()
        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null || items.size >= maxItems) return
            val txt = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            if (!txt.isNullOrEmpty()) items.add(txt)
            else if (!desc.isNullOrEmpty()) items.add(desc)
            for (i in 0 until node.childCount) traverse(node.getChild(i))
        }
        traverse(root)
        return items.distinct().joinToString(" | ")
    }

    fun clickByText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = targetText.trim().lowercase()
        fun findAndClick(node: AccessibilityNodeInfo?): Boolean {
            if (node == null) return false
            val txt = node.text?.toString()?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            if ((txt.contains(q) || desc.contains(q)) && q.isNotEmpty()) {
                var clickableNode: AccessibilityNodeInfo? = node
                while (clickableNode != null && !clickableNode.isClickable) clickableNode = clickableNode.parent
                if (clickableNode != null) return clickableNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            for (i in 0 until node.childCount) if (findAndClick(node.getChild(i))) return true
            return false
        }
        return findAndClick(root)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (target == null) {
            fun findEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
                if (node == null) return null
                if (node.isEditable) return node
                for (i in 0 until node.childCount) {
                    val found = findEditable(node.getChild(i))
                    if (found != null) return found
                }
                return null
            }
            target = findEditable(root)
        }
        if (target == null) return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollScreen(direction: String): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val startY = if (direction.equals("down", true)) dm.heightPixels * 0.75f else dm.heightPixels * 0.25f
        val endY = if (direction.equals("down", true)) dm.heightPixels * 0.25f else dm.heightPixels * 0.75f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun performSystemNav(actionName: String): Boolean {
        return when (actionName.lowercase()) {
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "lock" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
            "screenshot" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false
            else -> false
        }
    }
}
