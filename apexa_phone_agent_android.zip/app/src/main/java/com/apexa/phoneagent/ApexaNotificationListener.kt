package com.apexa.phoneagent

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

class ApexaNotificationListener : NotificationListenerService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val cooldownMap = ConcurrentHashMap<String, Long>()
    private val supportedPackages = setOf("com.whatsapp", "com.whatsapp.w4b")

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName !in supportedPackages) return

        val prefs = getSharedPreferences("apexa_prefs", MODE_PRIVATE)
        if (!prefs.getBoolean("auto_reply_enabled", false)) return

        val notification = sbn.notification ?: return
        // Skip summary notifications
        if ((notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = notification.extras ?: return
        val sender = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val incomingText = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (sender.isBlank() || incomingText.isBlank()) return

        // Avoid replying to same sender within 25 seconds
        val now = System.currentTimeMillis()
        val lastTime = cooldownMap[sender] ?: 0L
        if (now - lastTime < 25_000L) return

        // Find Direct Reply action with RemoteInput
        val replyAction = notification.actions?.firstOrNull { act ->
            act.remoteInputs != null && act.remoteInputs.isNotEmpty()
        } ?: return

        cooldownMap[sender] = now

        val provider = prefs.getString("provider", "groq") ?: "groq"
        val apiKey = prefs.getString("api_key", "").orEmpty()
        val lang = prefs.getString("lang", "gu") ?: "gu"
        val customRule = prefs.getString(
            "auto_reply_rule",
            "નમસ્તે! હું અત્યારે વ્યસ્ત છું. તમારો મેસેજ મળી ગયો છે, થોડીવારમાં જવાબ આપીશ."
        ).orEmpty()

        serviceScope.launch {
            val replyText = if (apiKey.isNotBlank()) {
                try {
                    AiBrain.askAutoReply(provider, apiKey, sender, incomingText, lang, customRule)
                } catch (_: Exception) {
                    customRule
                }
            } else {
                customRule
            }

            sendDirectReply(replyAction, replyText)
        }
    }

    private fun sendDirectReply(action: Notification.Action, replyText: String) {
        try {
            val intent = Intent()
            val bundle = Bundle()
            for (remoteInput in action.remoteInputs) {
                bundle.putCharSequence(remoteInput.resultKey, replyText)
            }
            RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
            action.actionIntent.send(this, 0, intent)
        } catch (_: Exception) {
            // Ignored if notification expired before reply sent
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
