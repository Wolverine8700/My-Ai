package com.apexa.phoneagent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.util.Locale

class ApexaWakeWordService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "apexa_wake_channel"
        const val NOTIF_ID = 2026
        @Volatile
        var isRunning = false
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var awaitingCommand = false
    private var isProcessing = false

    private val wakeKeywords = listOf(
        "હે અપેક્ષા", "અપેક્ષા", "અપેક્શા", "अपेक्षा", "हे अपेक्षा",
        "hey apexa", "apexa", "apeksha", "hey apeksha", "apex"
    )

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        tts = TextToSpeech(this, this)
        createNotificationChannel()
        val notif = buildNotification("અપેક્ષા AI બેકગ્રાઉન્ડમાં સક્રિય છે — 'હે અપેક્ષા' બોલો")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
        mainHandler.postDelayed({ startListening() }, 500L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "અપેક્ષા AI વૉઇસ લિસનર", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("અપેક્ષા AI ચાલુ છે")
            .setContentText(text)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()
    }

    private fun startListening() {
        if (!isRunning || isProcessing) return
        try {
            speechRecognizer?.destroy()
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer = sr

            val prefs = getSharedPreferences("apexa_prefs", MODE_PRIVATE)
            val lang = prefs.getString("lang", "gu") ?: "gu"
            val langCode = when (lang) { "hi" -> "hi-IN"; "en" -> "en-IN"; else -> "gu-IN" }

            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    scheduleRestart(900L)
                }

                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (spoken.isNotEmpty()) {
                        handleHeardSpeech(spoken)
                    } else {
                        scheduleRestart(700L)
                    }
                }
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            sr.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart(1500L)
        }
    }

    private fun handleHeardSpeech(spoken: String) {
        val lower = spoken.lowercase()
        val matchedWake = wakeKeywords.firstOrNull { lower.contains(it.lowercase()) }

        if (awaitingCommand) {
            awaitingCommand = false
            executeVoiceCommand(spoken)
            return
        }

        if (matchedWake != null) {
            // Strip the wake word to see if the user already spoke a command in the same breath
            val idx = lower.indexOf(matchedWake.lowercase())
            val remainder = spoken.substring(idx + matchedWake.length).trim()
            if (remainder.length >= 2) {
                executeVoiceCommand(remainder)
            } else {
                awaitingCommand = true
                speakAndRestart("હા, બોલો!", 1400L)
            }
        } else {
            scheduleRestart(650L)
        }
    }

    private fun executeVoiceCommand(command: String) {
        val prefs = getSharedPreferences("apexa_prefs", MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "").orEmpty().trim()
        val provider = prefs.getString("provider", "groq") ?: "groq"
        val lang = prefs.getString("lang", "gu") ?: "gu"

        if (apiKey.isBlank()) {
            speakAndRestart("પહેલા એપમાં API Key સેવ કરો.", 2200L)
            return
        }

        isProcessing = true
        serviceScope.launch {
            try {
                val screenText = ApexaAccessibilityService.instance?.readScreenText() ?: "Background"
                val plan = AiBrain.ask(provider, apiKey, command, lang, screenText)
                PhoneTools.executeActions(this@ApexaWakeWordService, plan.actions)
                speakAndRestart(plan.reply, 2600L)
            } catch (_: Exception) {
                speakAndRestart("માફ કરશો, કમાન્ડમાં ભૂલ આવી.", 2000L)
            } finally {
                isProcessing = false
            }
        }
    }

    private fun speakAndRestart(text: String, delayMs: Long) {
        val prefs = getSharedPreferences("apexa_prefs", MODE_PRIVATE)
        val lang = prefs.getString("lang", "gu") ?: "gu"
        val locale = when (lang) { "hi" -> Locale("hi", "IN"); "en" -> Locale("en", "IN"); else -> Locale("gu", "IN") }
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "apexa_wake_tts")
        scheduleRestart(delayMs)
    }

    private fun scheduleRestart(delayMs: Long) {
        mainHandler.removeCallbacksAndMessages(null)
        if (isRunning) {
            mainHandler.postDelayed({ startListening() }, delayMs)
        }
    }

    override fun onInit(status: Int) {}

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        tts?.shutdown()
        serviceScope.cancel()
        super.onDestroy()
    }
}
