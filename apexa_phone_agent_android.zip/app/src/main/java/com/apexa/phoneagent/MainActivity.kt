package com.apexa.phoneagent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tvAccessStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var etCommand: EditText
    private lateinit var etApiKey: EditText
    private lateinit var etAutoReplyRule: EditText
    private lateinit var swAutoReply: Switch
    private lateinit var swWakeWord: Switch
    private lateinit var spProvider: Spinner
    private lateinit var spLang: Spinner

    private var tts: TextToSpeech? = null
    private val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val prefs by lazy { getSharedPreferences("apexa_prefs", MODE_PRIVATE) }

    private val providers = arrayOf("groq", "gemini", "openrouter")
    private val langs = arrayOf("gu", "hi", "en")

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            etCommand.setText(spoken)
            runCommand(spoken)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvAccessStatus = findViewById(R.id.tvAccessStatus)
        tvLog = findViewById(R.id.tvLog)
        etCommand = findViewById(R.id.etCommand)
        etApiKey = findViewById(R.id.etApiKey)
        etAutoReplyRule = findViewById(R.id.etAutoReplyRule)
        swAutoReply = findViewById(R.id.swAutoReply)
        swWakeWord = findViewById(R.id.swWakeWord)
        spProvider = findViewById(R.id.spProvider)
        spLang = findViewById(R.id.spLang)

        tts = TextToSpeech(this, this)

        spProvider.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("GroqCloud (Fast Free)", "Google Gemini", "OpenRouter (Free)"))
        spLang.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("ગુજરાતી (gu-IN)", "हिन्दी (hi-IN)", "English (en-IN)"))

        spProvider.setSelection(providers.indexOf(prefs.getString("provider", "groq")).coerceAtLeast(0))
        spLang.setSelection(langs.indexOf(prefs.getString("lang", "gu")).coerceAtLeast(0))
        etApiKey.setText(prefs.getString("api_key", ""))
        swAutoReply.isChecked = prefs.getBoolean("auto_reply_enabled", false)
        swWakeWord.isChecked = ApexaWakeWordService.isRunning || prefs.getBoolean("wake_word_enabled", false)

        swWakeWord.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("wake_word_enabled", isChecked).apply()
            val svcIntent = Intent(this, ApexaWakeWordService::class.java)
            if (isChecked) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestCorePermissions()
                    swWakeWord.isChecked = false
                    Toast.makeText(this, "પહેલા માઇક્રોફોન પરમિશન આપો", Toast.LENGTH_SHORT).show()
                } else {
                    ContextCompat.startForegroundService(this, svcIntent)
                    Toast.makeText(this, "બેકગ્રાઉન્ડ 'હે અપેક્ષા' ચાલુ થઈ ગયું!", Toast.LENGTH_SHORT).show()
                }
            } else {
                stopService(svcIntent)
                Toast.makeText(this, "બેકગ્રાઉન્ડ વેક-વર્ડ બંધ કર્યું", Toast.LENGTH_SHORT).show()
            }
        }
        etAutoReplyRule.setText(
            prefs.getString(
                "auto_reply_rule",
                "નમસ્તે! હું અત્યારે વ્યસ્ત છું, તમારો મેસેજ મળી ગયો છે. ઓર્ડર કે બિઝનેસ માટે વિગત લખી મોકલો."
            )
        )

        findViewById<Button>(R.id.btnEnableAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnEnableNotif).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        swAutoReply.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_reply_enabled", isChecked).apply()
            Toast.makeText(this, if (isChecked) "WhatsApp ઑટો-રિપ્લાય ચાલુ!" else "ઑટો-રિપ્લાય બંધ", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSaveKey).setOnClickListener {
            prefs.edit()
                .putString("provider", providers[spProvider.selectedItemPosition])
                .putString("lang", langs[spLang.selectedItemPosition])
                .putString("api_key", etApiKey.text.toString().trim())
                .putBoolean("auto_reply_enabled", swAutoReply.isChecked)
                .putString("auto_reply_rule", etAutoReplyRule.text.toString().trim())
                .apply()
            Toast.makeText(this, "અપેક્ષા AI સેટિંગ્સ સેવ થયા!", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnSpeak).setOnClickListener { startVoiceInput() }
        findViewById<Button>(R.id.btnSend).setOnClickListener {
            val cmd = etCommand.text.toString().trim()
            if (cmd.isNotEmpty()) runCommand(cmd)
        }

        requestCorePermissions()
    }

    override fun onResume() {
        super.onResume()
        val active = ApexaAccessibilityService.isRunning()
        tvAccessStatus.text = if (active) "✅ ફોન કંટ્રોલ: ચાલુ | ઑટો-રિપ્લાય: ${if (swAutoReply.isChecked) "ON" else "OFF"}"
        else "⚠️ ફોન કંટ્રોલ: બંધ (Accessibility ચાલુ કરો)"
    }

    private fun requestCorePermissions() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.CAMERA).apply { if (android.os.Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS) }
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 101)
    }

    private fun startVoiceInput() {
        val langCode = when (langs[spLang.selectedItemPosition]) { "hi" -> "hi-IN"; "en" -> "en-IN"; else -> "gu-IN" }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langCode)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "અપેક્ષા સાંભળી રહી છે...")
        }
        try { voiceLauncher.launch(intent) } catch (_: Exception) { Toast.makeText(this, "વૉઇસ ઇનપુટ ઉપલબ્ધ નથી", Toast.LENGTH_SHORT).show() }
    }

    private fun runCommand(command: String) {
        val apiKey = prefs.getString("api_key", "").orEmpty().ifBlank { etApiKey.text.toString().trim() }
        val provider = providers[spProvider.selectedItemPosition]
        val lang = langs[spLang.selectedItemPosition]
        if (apiKey.isBlank()) {
            tvLog.text = "⚠️ પહેલા નીચે Groq, Gemini અથવા OpenRouter ની API Key સેવ કરો."
            return
        }
        tvLog.text = "તમે: $command\n⏳ અપેક્ષા વિચારી રહી છે..."
        uiScope.launch {
            try {
                val screenText = ApexaAccessibilityService.instance?.readScreenText() ?: "Accessibility OFF"
                val plan = AiBrain.ask(provider, apiKey, command, lang, screenText)
                val execLogs = PhoneTools.executeActions(this@MainActivity, plan.actions)
                val summary = if (execLogs.isNotEmpty()) "\n⚡ એક્શન: ${execLogs.joinToString(" → ")}" else ""
                tvLog.text = "તમે: $command\n\nઅપેક્ષા AI: ${plan.reply}$summary"
                speak(plan.reply, lang)
            } catch (e: Exception) {
                tvLog.text = "❌ ભૂલ: ${e.message}"
            }
        }
    }

    private fun speak(text: String, lang: String) {
        val locale = when (lang) { "hi" -> Locale("hi", "IN"); "en" -> Locale("en", "IN"); else -> Locale("gu", "IN") }
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "apexa_tts")
    }

    override fun onInit(status: Int) {}
    override fun onDestroy() { super.onDestroy(); uiScope.cancel(); tts?.shutdown() }
}
