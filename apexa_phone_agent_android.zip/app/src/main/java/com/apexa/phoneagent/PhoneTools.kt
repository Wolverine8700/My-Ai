package com.apexa.phoneagent

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

object PhoneTools {

    fun openAppByName(context: Context, appName: String): String {
        val q = appName.trim().lowercase()
        val pm = context.packageManager
        val aliases = mapOf(
            "whatsapp business" to "com.whatsapp.w4b",
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "maps" to "com.google.android.apps.maps",
            "gmail" to "com.google.android.gm",
            "sheets" to "com.google.android.apps.docs.editors.sheets",
            "google sheets" to "com.google.android.apps.docs.editors.sheets",
            "settings" to "com.android.settings"
        )
        aliases[q]?.let { pkg ->
            pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return "Opened $appName"
            }
        }
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        for (info in apps) {
            val label = info.loadLabel(pm).toString().lowercase()
            if (label.contains(q) || q.contains(label)) {
                pm.getLaunchIntentForPackage(info.activityInfo.packageName)?.let { intent ->
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return "Opened ${info.loadLabel(pm)}"
                }
            }
        }
        return "App not found: $appName"
    }

    fun makePhoneCall(context: Context, phone: String): String {
        val digits = phone.filter { it.isDigit() || it == '+' }
        if (digits.isEmpty()) return "Invalid phone number"
        val hasCallPerm = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
        context.startActivity(Intent(action, Uri.parse("tel:$digits")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Calling $digits"
    }

    fun sendWhatsApp(context: Context, phone: String, message: String): String {
        val digits = phone.filter { it.isDigit() }
        val enc = URLEncoder.encode(message, "UTF-8")
        val url = if (digits.isNotEmpty()) "https://wa.me/$digits?text=$enc" else "https://wa.me/?text=$enc"
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened WhatsApp chat"
    }

    fun toggleFlashlight(context: Context, turnOn: Boolean): String {
        return try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cm.cameraIdList.firstOrNull() ?: return "No flash available"
            cm.setTorchMode(cameraId, turnOn)
            if (turnOn) "Flashlight ON" else "Flashlight OFF"
        } catch (e: Exception) {
            "Flashlight error: ${e.message}"
        }
    }

    fun adjustVolume(context: Context, mode: String): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (mode.lowercase()) {
            "up" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "Volume raised" }
            "down" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "Volume lowered" }
            "mute" -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "Muted" }
            "max" -> { am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI); "Volume max" }
            else -> "Volume unchanged"
        }
    }

    fun setAlarm(context: Context, hour: Int, minute: Int, label: String): String {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, label.ifBlank { "અપેક્ષા AI એલાર્મ" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "Alarm set for $hour:$minute"
    }

    fun openWebOrSearch(context: Context, query: String): String {
        val url = if (query.startsWith("http://") || query.startsWith("https://")) query
        else "https://www.google.com/search?q=${URLEncoder.encode(query, "UTF-8")}"
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened browser"
    }

    fun openSettingsPanel(context: Context, panel: String): String {
        val action = when (panel.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened $panel settings"
    }

    suspend fun executeActions(context: Context, actions: JSONArray): List<String> {
        val logs = mutableListOf<String>()
        for (i in 0 until actions.length()) {
            val act: JSONObject = actions.optJSONObject(i) ?: continue
            val type = act.optString("type", "").lowercase()
            val value = act.optString("value", "")
            val result = when (type) {
                "open_app" -> openAppByName(context, value)
                "call" -> makePhoneCall(context, value)
                "whatsapp" -> sendWhatsApp(context, act.optString("phone", ""), act.optString("message", value))
                "flashlight" -> toggleFlashlight(context, value.equals("on", true) || value.equals("true", true))
                "volume" -> adjustVolume(context, value)
                "alarm" -> setAlarm(context, act.optInt("hour", 7), act.optInt("minute", 0), value)
                "search", "open_url" -> openWebOrSearch(context, value)
                "settings" -> openSettingsPanel(context, value)
                "click_text" -> if (ApexaAccessibilityService.instance?.clickByText(value) == true) "Tapped '$value'" else "Could not find '$value'"
                "type_text" -> if (ApexaAccessibilityService.instance?.typeText(value) == true) "Typed text" else "No active input field"
                "scroll" -> if (ApexaAccessibilityService.instance?.scrollScreen(value) == true) "Scrolled $value" else "Accessibility OFF"
                "nav" -> if (ApexaAccessibilityService.instance?.performSystemNav(value) == true) "Nav: $value" else "Accessibility OFF"
                "wait" -> { delay(act.optLong("ms", 1200L)); "Waited" }
                else -> "Unknown action: $type"
            }
            logs.add(result)
            if (i < actions.length() - 1) delay(900L)
        }
        return logs
    }
}
